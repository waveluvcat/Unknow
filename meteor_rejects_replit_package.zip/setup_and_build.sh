#!/usr/bin/env bash
set -euo pipefail
echo "Starting setup_and_build.sh"
echo "This script clones AntiCope/meteor-rejects, copies the local meteor-client jar, patches build.gradle, then builds."
# 1) Clone repo
if [ ! -d "meteor-rejects" ]; then
  git clone https://github.com/AntiCope/meteor-rejects.git
else
  echo "meteor-rejects folder already exists, pulling latest..."
  (cd meteor-rejects && git fetch --all && git reset --hard origin/HEAD)
fi
cd meteor-rejects
# 2) copy jar into libs/
mkdir -p libs
cp ../meteor-client-1.21.8-38.jar libs/
# 3) patch build.gradle to use local jar
echo "Patching build.gradle to use local meteor-client jar..."
python3 ../patch_build.py build.gradle libs/meteor-client-1.21.8-38.jar
# 4) run gradle build
echo "Running ./gradlew build (this may take several minutes)..."
# Ensure gradlew is executable
chmod +x gradlew || true
./gradlew build --no-daemon
echo "Build finished. Look for the jars in meteor-rejects/build/libs/"
ls -la build/libs || true

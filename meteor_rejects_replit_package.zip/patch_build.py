#!/usr/bin/env python3
import sys
from pathlib import Path
if len(sys.argv) != 3:
    print("Usage: patch_build.py <build.gradle path> <relative-path-to-jar-inside-project>")
    sys.exit(2)
build_gradle = Path(sys.argv[1])
jar_rel = sys.argv[2].replace("\\", "/")
if not build_gradle.exists():
    print(f"Error: {build_gradle} not found")
    sys.exit(1)
text = build_gradle.read_text(encoding='utf-8')
# Heuristic replacement: find any implementation/compile of meteor-client artifact and replace the whole line
import re
pattern = re.compile(r'(^\s*(implementation|compile)\s+["\'][^"\']*meteor-client[^"\']*["\'].*$)', re.MULTILINE)
if pattern.search(text):
    new_line = f"implementation files('{jar_rel}')"
    text_new = pattern.sub(new_line, text, count=1)
    build_gradle.write_text(text_new, encoding='utf-8')
    print(f"Patched {build_gradle} to use local jar: {jar_rel}")
else:
    # If not found, append a local dependency to dependencies block (best effort)
    deps_pattern = re.compile(r'(dependencies\s*\{)', re.MULTILINE)
    if deps_pattern.search(text):
        text_new = deps_pattern.sub(r"\1\n    implementation files('" + jar_rel + "')", text, count=1)
        build_gradle.write_text(text_new, encoding='utf-8')
        print(f"Added local jar dependency to dependencies{{}} in {build_gradle}")
    else:
        # fallback: append a dependencies block
        text_new = text + "\n\ndependencies {\n    implementation files('" + jar_rel + "')\n}\n"
        build_gradle.write_text(text_new, encoding='utf-8')
        print(f"Appended new dependencies block to {build_gradle} with local jar")

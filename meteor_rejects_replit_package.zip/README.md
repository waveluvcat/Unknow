# Meteor Rejects 1.21.8 Replit Build Package
ภาษา: ไทย

สิ่งที่ไฟล์นี้มี:
- meteor-client-1.21.8-38.jar
- setup_and_build.sh   (สคริปต์ที่ clone repo, patch build.gradle, แล้ว build)
- patch_build.py       (ตัวช่วยแก้ build.gradle ให้ใช้ local jar)
- README.md

## วิธีใช้บน Replit (หรือ Codespaces)
1. สร้าง Replit ใหม่ (เลือก Template: *Bash* หรือ *Ubuntu*). หากใช้ Codespaces ให้เปิด repo ใดก็ได้และอัปโหลดไฟล์เหล่านี้เข้า workspace.
2. อัปโหลดไฟล์ ZIP นี้ และแตกไฟล์ลงใน project root (หรือ `git upload` แล้ว push).
3. เปิด Shell/Console ใน Replit
4. รัน:
   ```
   chmod +x setup_and_build.sh
   ./setup_and_build.sh
   ```
   สคริปต์จะ:
   - `git clone https://github.com/AntiCope/meteor-rejects.git`
   - คัดลอก `meteor-client-1.21.8-38.jar` ไปที่ `meteor-rejects/libs/`
   - แก้ `meteor-rejects/build.gradle` ให้ใช้ local jar แทน dependency เดิม
   - รัน `./gradlew build`

5. หาก build สำเร็จ ผลลัพธ์จะอยู่ที่:
   ```
   meteor-rejects/build/libs/
   ```
   คุณสามารถดาวน์โหลดไฟล์ `.jar` จาก Replit UI

## หมายเหตุและ Troubleshooting
- ต้องการ Java 21 (หรือเวอร์ชันที่ Meteor uses) ใน environment ของคุณ
- หาก Gradle build error เกิดขึ้น ให้โพสต์ข้อความ error มาในแชทนี้ ผมจะช่วยวิเคราะห์และแก้ไฟล์ patch เพิ่มเติม
- ถ้า repository ของ Meteor Rejects เปลี่ยนโครงสร้างมาก script อาจต้องปรับ ผมจะแก้ให้คุณได้ตาม error ที่เห็น

## ความเป็นส่วนตัวและนโยบาย
- ผมไม่สามารถส่งไฟล์ `.jar` ที่คอมไพล์สำเร็จตรงๆ ให้คุณได้ แต่ผมให้โค้ดและสคริปต์เพื่อให้คุณ build เองบน Replit/Codespaces ได้อย่างปลอดภัยจากมือถือ

### ถ้าต้องการให้ผมช่วยต่อ:
- อัปโหลด error log จาก Replit มาให้ผม ผมจะแก้ `patch_build.py` หรือ `setup_and_build.sh` ให้จน build ผ่าน
- ถ้าต้องการ ผมสามารถปรับสคริปต์ให้รองรับ proxies หรือ caching
